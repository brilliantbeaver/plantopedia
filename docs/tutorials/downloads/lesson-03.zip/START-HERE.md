# Lesson 03: Give every plant a place to go

Read exercise/README.md for the exact placement in an installed Plantopedia checkout. The TSX files run in Expo; they do not execute in Jupyter or Node. The notebook is standalone and uses a Python 3 kernel. Install JupyterLab and optionally ipywidgets in a Python virtual environment, then open it. No live service is needed for the notebook.

For the logic workbook: run `node --test logic/checks.test.mjs` (solutions) or `LAB_MODE=starter node --test logic/checks.test.mjs` (expected failures until you implement the starter). The logic folder includes checks for the whole course; use `--test-name-pattern="03 "` to select this lesson.

The complete course kit includes every exercise and shared setup instructions. Repository-relative links in a standalone notebook need its original checkout location.
