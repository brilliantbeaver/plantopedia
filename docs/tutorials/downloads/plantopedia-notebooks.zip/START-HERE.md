# Plantopedia notebook bundle

Extract the ZIP before opening a notebook. This download contains ten standalone Python notebooks in `notebooks/`. It does not contain the interactive HTML guide or Expo exercise workspace; those are separate downloads.

From this extracted folder, create a Python 3.9+ environment and start Jupyter:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install jupyterlab ipywidgets
jupyter lab notebooks
```

On Windows, activate the environment with `.venv\Scripts\activate.bat` in Command Prompt instead of the `source` command. Choose the Python 3 kernel and run cells in order. Widgets are optional. Without widgets, edit an explorer function's default arguments and rerun its model cell; the active defaults are printed. Prediction cells start with `None` and do not count as attempted until edited.

The notebooks include lesson text, embedded SVGs, fixtures, Python models, and TSX examples for reading. Python does not run React Native. No cloud account, camera, microphone, or live API is used by the models. Run TSX in the configured Expo repository using the separate exercise workspace. Repository and course companion links work only when those files are present in their original relative locations. Save each notebook to keep your work.
