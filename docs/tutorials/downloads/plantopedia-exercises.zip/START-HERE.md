# Plantopedia exercise workspace

Extract the ZIP first, then open [the exercise instructions](exercises/README.md). This download contains editable React Native starters, worked solutions, a fixture-backed capstone, and dependency-free JavaScript checks. It does not contain the HTML course or Jupyter notebooks; those are separate downloads.

From this extracted folder, run the worked logic checks:

```sh
cd exercises
node --test logic/checks.test.mjs
```

To practice, edit `logic/starter.mjs` and run `LAB_MODE=starter node --test logic/checks.test.mjs` in a POSIX shell. In PowerShell, use `$env:LAB_MODE='starter'; node --test logic/checks.test.mjs`. The starters intentionally fail until completed.

Node checks exercise bounded JavaScript models. TSX screens run through Expo in an installed Plantopedia checkout, after the documented setup and file placement in `exercises/README.md`. Use the repository's pinned Node 22.23.1, npm 12.0.2, and Expo 57 setup for app work. Camera, native glass, durable device storage, and microphone behavior still need device acceptance. No new cloud integration is provisioned by these exercises.
